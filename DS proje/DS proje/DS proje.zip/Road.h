#pragma once
class Road
{
public:
	Road()
	{
		;
	}
	Road operator=(const Road& other)
	{
		;
	}
};

